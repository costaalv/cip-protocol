# CIP SDK — Primal Integrity Cipher

**Research Artifact and Demonstration Binary**

## Overview

The **CIP SDK (Primal Integrity Cipher)** is a compiled research artifact demonstrating a file integrity and security protocol grounded in **spectral coherence derived from prime number arithmetic**.

This deposit provides an **executable binary** implementing the operational consequences of the theoretical framework described in the accompanying Zenodo publication.

The SDK is released **for evaluation, testing, and reproducibility purposes**.

---

## Core Operations

The `cip` binary supports four fundamental operations on digital files:

* **sign** — generate a spectral integrity signature;
* **verify** — validate a previously generated signature;
* **encrypt** — encrypt file contents;
* **decrypt** — decrypt previously encrypted files.

These operations are available in two distinct execution modes.

---

## Execution Modes

### 1. Standard Mode

Applies direct operations to a single file.

* `sign` — generates a spectral signature;
* `verify` — validates a spectral signature;
* `encrypt` — encrypts file contents;
* `decrypt` — decrypts a previously encrypted file.

### 2. Full Mode (`-t` flag)

Enables extended analysis and produces detailed audit artifacts.
Activated by the `-t` flag **before** the operation.

Examples:

* `cip -t sign`
* `cip -t verify`
* `cip -t encrypt`
* `cip -t decrypt`

In full mode, additional forensic and audit metadata are generated alongside the operation.

---

## Basic Usage Examples

### Sign a file (standard mode)

```bash
./cip sign document.pdf
```

### Verify a signature

```bash
./cip verify document.pdf .cip/keys/chave_cip_assinado_(...).json
```

### Encrypt a file

```bash
./cip encrypt data.csv
```

### Decrypt a file

```bash
./cip decrypt data.csv .cip/keys/chave_cip_cifrado_(...).json
```

### Generate a full audited signature

```bash
./cip -t sign report.docx
```

---

## Windows Execution Notes

To execute `cip.exe` correctly on Windows systems:

* Extract **all contents** of the `.zip` archive into a single directory;
* Open **Command Prompt or PowerShell** and navigate to that directory;
* Execute commands **from that directory**, where `cip.exe`, required DLLs, and the `data/` folder are located;
* Do **not** move the executable without the accompanying DLLs and `data/` directory.

> The CIP SDK is designed for **command-line execution only**.
> Double-clicking `cip.exe` is not supported.

---

## Demonstration Version and Execution Limits

This release is a **demonstration build** intended for evaluation and educational use.

* The SDK includes **100 execution credits**;
* Credits are consumed by the `verify` and `decrypt` operations (in both modes);
* `sign` and `encrypt` operations are unrestricted in this build.

### Integrity of the Credit Counter

* The execution counter (`contador.cip`) is generated inside the `data/` directory;
* This file is **cryptographically signed by the SDK itself**;
* Any deletion or modification permanently disables the binary.

This mechanism is part of the integrity model under evaluation.

---

## Windows Runtime Dependencies

The Windows package includes all required runtime libraries.
These files **must remain in the same directory** as `cip.exe`.

| File                  | Purpose               |
| --------------------- | --------------------- |
| `msvcp140.dll`        | Visual C++ runtime    |
| `vcruntime140.dll`    | Visual C++ runtime    |
| `vcruntime140_1.dll`  | Updated runtime       |
| `libssl-3-x64.dll`    | OpenSSL               |
| `libcrypto-3-x64.dll` | Cryptographic backend |
| `legacy.dll`          | Legacy crypto support |
| `zlib1.dll`           | Compression           |

Including these libraries ensures execution on clean or restricted systems without external installation steps.

---

## Technical Notes on the CIP Model

### Spectral Index (IDX)

Each execution relies on a **spectral index (IDX)** that defines a specific harmonic projection derived from prime number distribution.

An IDX determines a unique spectral matrix that underpins all operations performed by the SDK.

---

### Structural Integrity

Instead of hashing raw file bytes directly, the CIP SDK:

1. Projects file content into a spectral space;
2. Applies cryptographic hashing to the resulting vectors.

This makes integrity a **structural property**, not merely a binary checksum.
Minimal changes — including single-bit modifications — result in detectable spectral divergence.

---

### Vector-Based Encryption

Encryption is derived from the file content itself:

* Random content blocks are projected into spectral space;
* The resulting vectors seed a cryptographic key derivation process;
* Decryption requires:

  * the same IDX,
  * the correct block order,
  * and preserved integrity.

No external passwords or user-supplied keys are involved.

---

## Demonstration Build Scope

This demonstration binary uses a **shared generic spectral index**.

As a result:

* Files signed with this build can be verified by other demonstration builds;
* Signatures generated by SDKs using exclusive indices are **not verifiable** by this binary.

This limitation is intentional and documents the distinction between demonstration artifacts and fully interoperable deployments.

---

## License and Use Terms (Demonstration Build)

By using this SDK, you agree that:

1. The binary is provided **for evaluation and non-commercial use**;
2. Modification, decompilation, or reverse engineering is prohibited;
3. Users are solely responsible for files processed with the SDK;
4. This build does not guarantee interoperability beyond its documented scope.

---

## Project Reference

Further technical context and publications related to this artifact are available at:

**[https://delta-cip.com.br](https://delta-cip.com.br)**

---

> **DELTA-CIP — Arithmetic coherence, operationalized.**
